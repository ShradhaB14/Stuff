package com.DatabasePackage;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Designation {

	
	int desgid;
	String desgname;
	
	public Designation(){}
	public Designation(int desgid, String desgname) {
		super();
		this.desgid = desgid;
		this.desgname = desgname;
	}
	public int getDesgid() {
		return desgid;
	}
	public void setDesgid(int desgid) {
		this.desgid = desgid;
	}
	public String getDesgname() {
		return desgname;
	}
	public void setDesgname(String desgname) {
		this.desgname = desgname;
	}
	 public List<Designation> getDesignation()
	 {
		 List<Designation> desgList=new ArrayList<>();
		 try{
		 PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select desgid,desgname from designation");
		 ResultSet rs;
		  rs=ps.executeQuery();
		  
		 while(rs.next())
		 {
			 desgList.add(new Designation(rs.getInt("desgid"),rs.getString("desgname")));
			 System.out.println(rs.getInt(desgid)+rs.getString(desgname));
			// System.out.println("hieeeeeee");
		 }
	 }
	 
	 catch(Exception e)
	 {
		 e.getStackTrace();
	 }
		 return desgList;
}
	 
	 public static void main(String args[])
	 {
		 Designation dobj=new Designation();
		 List<Designation> dList=dobj.getDesignation();
		 Iterator<Designation> it=dList.iterator();
		// System.out.println("Hello");
		 while(it.hasNext())
		 {
			 Designation desgobj=(Designation)it.next();
			 System.out.println(desgobj.getDesgid()+desgobj.getDesgname());
		 }
		 
		 
	 }
}
