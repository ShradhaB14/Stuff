package com.DatabasePackage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class City {

	int cityid;
	String cityname;
	int stateid;
	
	public City(){}
	public City(int cityid, String cityname, int stateid) {
		super();
		this.cityid = cityid;
		this.cityname = cityname;
		this.stateid = stateid;
	}
	public int getCityid() {
		return cityid;
	}
	public void setCityid(int cityid) {
		this.cityid = cityid;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public int getStateid() {
		return stateid;
	}
	public void setStateid(int stateid) {
		this.stateid = stateid;
	}
	
	public List<City> getCityList(int stateid)
	{
		List<City> cityList=new ArrayList<>();
		try{
				
				PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select cityid,cityname,stateid from city where stateid=?");
				ResultSet rs;
				ps.setInt(1, stateid);
				rs=ps.executeQuery();
				while(rs.next())
				{
					cityList.add(new City(rs.getInt("stateid"),rs.getString("cityname"),rs.getInt("cityid")));
				}
		
		}
	catch(Exception e)
		{e.getMessage();}
		return cityList;
	}
	
/*public static void main(String args[])
{
		City cityobj=new City();
		List<City> list1=cityobj.getCityList();
		
		Iterator it=list1.iterator();
		while(it.hasNext())
		{
			City cityobj1=(City)it.next();
			System.out.println(cityobj1.getStateid()+cityobj1.getCityname()+cityobj1.getCityid());
		}

}*/
}
	
