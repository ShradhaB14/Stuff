package com.DatabasePackage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Country {

	int id;
	String countryname;
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCountryname() {
		return countryname;
	}


	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}

	

	public Country(int id, String countryname) {
		super();
		this.id = id;
		this.countryname = countryname;
	}


	
	public Country() {
		// TODO Auto-generated constructor stub
	}
	
	public List<Country> getCountryList()
	{
		List<Country> list1=new ArrayList<>();
		try{
		
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select countryid,cname from country");
			rs=ps.executeQuery();
			while(rs.next())
			{
				list1.add(new Country(rs.getInt("countryid"),rs.getString("cname")));
			}
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return list1;
	}
	
	
}
