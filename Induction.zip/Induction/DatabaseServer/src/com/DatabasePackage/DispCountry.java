package com.DatabasePackage;

import java.util.Iterator;
import java.util.List;

public class DispCountry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Country c=new Country();
		List<Country> list1=c.getCountryList();
		Iterator it=list1.listIterator();
		
		while(it.hasNext())
		{
			Country cobj=(Country)it.next();
			System.out.println(cobj.getId()+cobj.getCountryname());
		}
		

	}

}
