package com.DatabasePackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Connection con=DBConnectivity.getConnection();
		try{
		
		
		
		String fname=request.getParameter("name");
		
		String lname=request.getParameter("lname");
		
		String dob=request.getParameter("dob");
		
		String pnumber=request.getParameter("mobile");
		
		String email=request.getParameter("email");
		
		String address=request.getParameter("address");
		String country=request.getParameter("country");
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		String pincode=request.getParameter("pincode");
		String designation=request.getParameter("designation");
		String doj=request.getParameter("doj");
		
		//System.out.println(fname+lname);
		
		
		
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select MAX(eid) as max from employee");
		rs.next();
		int maxid=rs.getInt(1);
		
		ResultSet rs1=st.executeQuery("select cityid from city where cityname='"+city+"'");
		int cityid=0;
		if(rs1.next())
		{
			 cityid=rs1.getInt(1);
		}		
		
		rs1=st.executeQuery("select desgid from designation where desgname='"+designation+"'");
		System.out.println("select desgid from designation where desgname='"+designation+"'");
		int desgid=0;
		if(rs1.next())
		{
			desgid=rs1.getInt(1);
		}
		
		PreparedStatement ps=con.prepareStatement("insert into employee(fname,lname,dob,pnumber,email,street_address,countryid,stateid,cityid,pincode,eid,desgid,doj)values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
		
		ps.setString(1, fname);
		ps.setString(2, lname);
		ps.setString(3, dob);
		ps.setString(4, pnumber);
		ps.setString(5, email);
		ps.setString(6, address);
		ps.setString(7, country);
		ps.setString(8, state);
		ps.setInt(9, cityid);
		ps.setString(10, pincode);
		ps.setInt(11, maxid+1);
		ps.setInt(12, desgid);
		ps.setString(13, doj);
		
		
		ps.executeUpdate();
		
		response.sendRedirect("Details.jsp");
		}
		catch(Exception e)
		{
			System.out.println(e); 
		}
		
		
		
		
	}

}
