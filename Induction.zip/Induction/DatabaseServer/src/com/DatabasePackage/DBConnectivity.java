package com.DatabasePackage;
import java.sql.*;

public class DBConnectivity {

	
	public static Connection getConnection()
	{
		 String connectionUrl = "jdbc:sqlserver://HG-D137:1433;databaseName=HRMS1;"; 
	        // Declare the JDBC objects. 
	        Connection con = null;
	       
			try
			{
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
				con = DriverManager.getConnection(connectionUrl,"sa","test_1234");
				

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return con;
	}
	
	
	
}
