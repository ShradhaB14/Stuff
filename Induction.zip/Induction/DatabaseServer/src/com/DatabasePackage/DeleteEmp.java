package com.DatabasePackage;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteEmp
 */
public class DeleteEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteEmp() {
        super();
        
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		try{
			int id=Integer.parseInt(request.getParameter("empid"));
			PreparedStatement ps1=DBConnectivity.getConnection().prepareStatement("delete from payroll where eid=?");
			ps1.setInt(1,id);
			ps1.executeUpdate();
			
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("delete from employee where eid=?");
	
			ps.setInt(1,id);
			
			int d = ps.executeUpdate();
			
			
			if(d>0)
			{
				System.out.println("Deleted Successfully");
			}
			
		}
		catch(Exception e){
			e.getMessage();
		}
	}

}
