package com.DatabasePackage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class State {
	
	int sid;
	String sname;
	int countryid;
	public State()
	{}
	
	public State(int sid, String sname, int countryid) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.countryid = countryid;
	}
	
	

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getCountryid() {
		return countryid;
	}

	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}

	public List<State> getStateList(int countryid)
	{
		List<State> SList=new ArrayList<>();
		try{
				PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select stateid,sname,countryid from state where countryid=?");
				ps.setInt(1,countryid);
				
				ResultSet rs;
				rs=ps.executeQuery();
				
				while(rs.next())
				{
					SList.add(new State(rs.getInt("stateid"),rs.getString("sname"),rs.getInt("countryid")));
				}
	
			}
	
	catch(Exception e){
			System.out.println(e);
		}
		return SList;
	
	}
	
	
	public static void main(String args[])
	{
		
		State sobj=new State();
		List<State> list1=sobj.getStateList(10);
		//sobj.getStateList(10);
		Iterator it=list1.iterator();
		while(it.hasNext())
		{
			State st1=(State)it.next();
			System.out.println(st1.getSid()+st1.getSname()+st1.getCountryid());
		}
		
		//System.out.println("helloooo");
		
	}

}
