package com.DatabasePackage;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetByPhnum {
                
                private String name;
                private String eid;
                                
               public GetByPhnum(){}


                public GetByPhnum(String name, String eid) {
					super();
					this.name = name;
					this.eid = eid;
				}




				public String getName() {
					return name;
				}




				public void setName(String name) {
					this.name = name;
				}




				public String getEid() {
					return eid;
				}




				public void setEid(String eid) {
					this.eid = eid;
				}




				public List<GetByPhnum> getEmpPhone(String phone)
                {   
                                List<GetByPhnum> empDetail = new ArrayList<>();
                                try
                                {
                                                Statement stmt=null;
                                                  stmt=DBConnectivity.getConnection().createStatement();
                                                  ResultSet rs=stmt.executeQuery("select (fname +lname)as name,eid from employee where pnumber like '%"+phone+"%'");
                                                  while(rs.next())  
                                                  {
                                                                  System.out.println(rs.getString(1)+"  "+rs.getInt(2));
                                                                  GetByPhnum p = new GetByPhnum(rs.getString("name"),rs.getString("eid"));
                                                                  empDetail.add(p);
                                                                  
                                                  }
                                }
                                catch(SQLException se)
                                {
                                }
                                return empDetail;
                }

}
