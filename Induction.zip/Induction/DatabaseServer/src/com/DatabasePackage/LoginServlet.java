package com.DatabasePackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
				
			response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		
		try{
		String u=request.getParameter("username");	
		String p=request.getParameter("password");
		
		Connection con=DBConnectivity.getConnection();
		PreparedStatement ps=con.prepareStatement("select uname,paswd from admin where uname=? and paswd=?");
		
		ps.setString(1,u);
		ps.setString(2,p);
	
		int flag=0;
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			//out.println("Welcome");
	
			if(rs.getString(1).equalsIgnoreCase(u) && rs.getString(2).equals(p))
			{
				System.out.println(rs.getString(1)+rs.getString(2));
				response.sendRedirect("Details.jsp");
			}
			
		}
		if(flag==0)
			out.println("�nvalid");
		
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
