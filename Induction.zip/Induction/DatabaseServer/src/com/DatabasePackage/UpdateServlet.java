package com.DatabasePackage;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateServlet() {
        super();
       
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
			try{
				int eid=Integer.parseInt(request.getParameter("empid"));	
				String fname=request.getParameter("fname");
				String lname=request.getParameter("lname");
				String dob=request.getParameter("dob");
				String mobilenum=request.getParameter("mobilenum");
				String email=request.getParameter("email");
				String designation=request.getParameter("designation");
				String doj=request.getParameter("doj");
				String address=request.getParameter("address");
				System.out.println("designation"+designation);
				System.out.println(eid+fname+lname+dob+mobilenum+email+doj+address);
				
				int country=Integer.parseInt(request.getParameter("country"));
				int state=Integer.parseInt(request.getParameter("state"));
				
				System.out.println(country+state);
				
				String city=request.getParameter("city");
				System.out.println(city);
				String pincode=request.getParameter("pincode");
				
				PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select desgid from designation where desgname=?");
				ps.setString(1, designation);
				ResultSet rs=ps.executeQuery();
				rs.next();
				int desgid=rs.getInt(1);
				
				
				 ps=DBConnectivity.getConnection().prepareStatement("select cityid from city where cityname=?");
				ps.setString(1, city);
				 rs=ps.executeQuery();
				rs.next();
				int cityid=rs.getInt(1);
				
				
				
				
				 ps=DBConnectivity.getConnection().prepareStatement("update employee set fname=?,lname=?,dob=?,pnumber=?,email=?,desgid=?,doj=?,street_address=?,countryid=?,stateid=?,cityid=?,pincode=? where eid=?");
				
				ps.setString(1, fname);
				ps.setString(2,lname);
				ps.setString(3,dob);
				ps.setString(4,mobilenum);
				ps.setString(5,email);
				ps.setInt(6,desgid);
				ps.setString(7,doj);
				ps.setString(8,address);
				ps.setInt(9,country);
				ps.setInt(10,state);
				ps.setInt(11,cityid);
				ps.setString(12,pincode);
				ps.setInt(13, eid);
				ps.executeUpdate();
				response.sendRedirect("Details.jsp");
			}		
			catch(Exception e)
			{
				e.getMessage();
			}
			
	}

}
