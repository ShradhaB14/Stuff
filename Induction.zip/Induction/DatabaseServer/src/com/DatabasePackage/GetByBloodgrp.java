package com.DatabasePackage;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;


public class GetByBloodgrp {


	
    private String designation;
    private String count;

    
    public GetByBloodgrp()
    {}
    
	
	
	
	
	


    public GetByBloodgrp(String designation, String count) {
		super();
		this.designation = designation;
		this.count = count;
	}








	public String getDesignation() {
		return designation;
	}








	public void setDesignation(String designation) {
		this.designation = designation;
	}








	public String getCount() {
		return count;
	}








	public void setCount(String count) {
		this.count = count;
	}








	public List<GetByBloodgrp> getEmpdesg(String bg)
    {   
                    List<GetByBloodgrp> empDetail = new ArrayList<GetByBloodgrp>();
                    try
                    {
                                    Statement stmt=null;
                                      stmt=DBConnectivity.getConnection().createStatement();
                                      ResultSet rs=stmt.executeQuery("select desgname,COUNT(desgname) as no_of_employee from employee inner join designation on employee.desgid=designation.desgid where bgid =(select bgid from bloodgroup where (bgname like '%"+bg+"%'))group by desgname;");
//System.out.println("select designation,COUNT(designation) as no_of_employee from employee inner join designation on employee.desgid=designation.desgid where bgid =(select bgid from bloodgroup where bgname='"+bg+"')group by desgname;");
                                      while(rs.next())  
                                      {
                                                    //  System.out.println(rs.getString(1)+"  "+rs.getInt(2));
                                    	  GetByBloodgrp p = new GetByBloodgrp(rs.getString("desgname"),rs.getString("no_of_employee"));
                                                      empDetail.add(p);
                                                      
                                      }
                    }
                    catch(SQLException se)
                    {
                                    se.printStackTrace();
                                    System.out.println("Exception in BgSearch "+se.getMessage());
                    }
                    return empDetail;
    }



}
