package com.DatabasePackage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EditEmp {

	int eid,desgid,countryid,stateid,cityid;
	String firstname,lastname,dob,mobilenum,email,doj,address,pincode;
	public EditEmp(){}
	
	
	

	public EditEmp(int eid, int desgid, int countryid, int stateid, int cityid, String firstname, String lastname,
			String dob, String mobilenum, String email, String doj, String address, String pincode) {
		super();
		this.eid = eid;
		this.desgid = desgid;
		this.countryid = countryid;
		this.stateid = stateid;
		this.cityid = cityid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dob = dob;
		this.mobilenum = mobilenum;
		this.email = email;
		this.doj = doj;
		this.address = address;
		this.pincode = pincode;
	}




	public int getEid() {
		return eid;
	}




	public void setEid(int eid) {
		this.eid = eid;
	}




	public int getDesgid() {
		return desgid;
	}




	public void setDesgid(int desgid) {
		this.desgid = desgid;
	}




	public int getCountryid() {
		return countryid;
	}




	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}




	public int getStateid() {
		return stateid;
	}




	public void setStateid(int stateid) {
		this.stateid = stateid;
	}




	public int getCityid() {
		return cityid;
	}




	public void setCityid(int cityid) {
		this.cityid = cityid;
	}




	public String getFirstname() {
		return firstname;
	}




	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}




	public String getLastname() {
		return lastname;
	}




	public void setLastname(String lastname) {
		this.lastname = lastname;
	}




	public String getDob() {
		return dob;
	}




	public void setDob(String dob) {
		this.dob = dob;
	}




	public String getMobilenum() {
		return mobilenum;
	}




	public void setMobilenum(String mobilenum) {
		this.mobilenum = mobilenum;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getDoj() {
		return doj;
	}




	public void setDoj(String doj) {
		this.doj = doj;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getPincode() {
		return pincode;
	}




	public void setPincode(String pincode) {
		this.pincode = pincode;
	}




	public EditEmp editDetails(int id)
	{
		EditEmp emp1=new EditEmp();
		try{
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select eid,fname,lname,dob,pnumber,email,desgid,doj,street_address,countryid,stateid,cityid,pincode from employee where eid=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			emp1.setEid(rs.getInt(1));
			emp1.setFirstname(rs.getString(2));
			emp1.setLastname(rs.getString(3));
			emp1.setDob(rs.getString(4));
			emp1.setMobilenum(rs.getString(5));
			emp1.setEmail(rs.getString(6));
			emp1.setDesgid(rs.getInt(7));
			emp1.setDoj(rs.getString(8));
			emp1.setAddress(rs.getString(9));
			emp1.setCountryid(rs.getInt(10));
			emp1.setStateid(rs.getInt(11));
			emp1.setCityid(rs.getInt(12));
			emp1.setPincode(rs.getString(13));
			
			
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return emp1;
	}
	
	public String getDesignationName(int id)
	{
		String name="";
		try{
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select desgname from designation where desgid=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			 name=rs.getString(1);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return name;
	}
	public String getCountryName(int id)
	{
		String name="";
		try{
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select cname from country where countryid=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			 name=rs.getString(1);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return name;
	}
		
	public String getStateName(int id)
	{
		String name="";
		try{
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select sname from state where stateid=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			 name=rs.getString(1);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return name;
	}
	public String getCityName(int id)
	{
		String name="";
		try{
			ResultSet rs;
			PreparedStatement ps=DBConnectivity.getConnection().prepareStatement("select cityname from city where cityid=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			rs.next();
			 name=rs.getString(1);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return name;
	}
}
