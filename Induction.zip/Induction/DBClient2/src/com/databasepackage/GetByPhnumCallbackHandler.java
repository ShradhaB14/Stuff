
/**
 * GetByPhnumCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

    package com.databasepackage;

    /**
     *  GetByPhnumCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class GetByPhnumCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public GetByPhnumCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public GetByPhnumCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
               // No methods generated for meps other than in-out
                
           /**
            * auto generated Axis2 call back method for getEid method
            * override this method for handling normal response from getEid operation
            */
           public void receiveResultgetEid(
                    com.databasepackage.GetByPhnumStub.GetEidResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from getEid operation
           */
            public void receiveErrorgetEid(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for getName method
            * override this method for handling normal response from getName operation
            */
           public void receiveResultgetName(
                    com.databasepackage.GetByPhnumStub.GetNameResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from getName operation
           */
            public void receiveErrorgetName(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for getEmpPhone method
            * override this method for handling normal response from getEmpPhone operation
            */
           public void receiveResultgetEmpPhone(
                    com.databasepackage.GetByPhnumStub.GetEmpPhoneResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from getEmpPhone operation
           */
            public void receiveErrorgetEmpPhone(java.lang.Exception e) {
            }
                
               // No methods generated for meps other than in-out
                


    }
    